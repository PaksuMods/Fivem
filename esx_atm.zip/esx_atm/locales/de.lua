Locales['de'] = {
  ['invalid_amount'] = '~r~Ungültiger Betrag',
  ['deposit_money']  = 'eingezahlt ~g~$%s~s~',
  ['withdraw_money'] = 'abgehoben ~g~$%s~s~', 
  ['press_e_atm']    = 'Drücke ~INPUT_PICKUP~ um auf den ~g~ATM~s~ zuzugreifen.',
  ['atm_blip']       = 'ATM',
}
