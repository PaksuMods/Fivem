Locales['fr'] = {
  ['invalid_amount'] = '~r~Montant invalide~s~',
  ['deposit_money']  = 'vous avez déposé ~g~$%s~s~',
  ['withdraw_money'] = 'vous avez retiré ~g~$%s~s~',
  ['press_e_atm']    = 'appuyez sur ~INPUT_PICKUP~ pour déposer ou retirer du ~g~cash~s~.',
  ['atm_blip']       = 'ATM',
}